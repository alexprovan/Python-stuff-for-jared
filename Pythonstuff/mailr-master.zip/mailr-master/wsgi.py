from mailr import app

application = app.create_app()
